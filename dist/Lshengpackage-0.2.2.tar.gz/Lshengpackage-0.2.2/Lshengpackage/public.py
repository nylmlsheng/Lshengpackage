# 全局变量
# coding:utf-8
# !/usr/bin/env python#
import sys

# 全局路径
path = sys.path[0]+"\\picture\\" #文件夹名称请自行修改



# #图片文件
#shot_pic = "shot_pic.png" #截图文件
scr = "full.png"


adb_shell = "adb shell /system/bin/screencap -p ../sdcard/"

adb_pull = "adb pull /sdcard/"

