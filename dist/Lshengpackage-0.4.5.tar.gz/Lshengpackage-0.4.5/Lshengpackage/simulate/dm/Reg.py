# !/usr/bin/env python
# -*-coding:utf-8 -*-

# windows 系统如需要登录时取消注释
# import win32com.client
#
#
# class RegDm:
#     """
#     大漠对象注册
#     """
#
#     @classmethod
#     def reg(cls):
#         dm = win32com.client.Dispatch('dm.dmsoft')
#         return dm

